export interface Movie {
  movieId?: string;
  title: string;
  director: string;
  genre: string;
  releaseYear: number;
  rating: number; 
}
