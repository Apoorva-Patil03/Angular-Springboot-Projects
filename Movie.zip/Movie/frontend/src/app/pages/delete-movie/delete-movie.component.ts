// src/app/pages/delete-movie/delete-movie.component.ts
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../../services/movie.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-delete-movie',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-movie.component.html',
  styleUrls: ['./delete-movie.component.css']
})
export class DeleteMovieComponent {
  movieId!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private movieService: MovieService
  ) {
    this.movieId = Number(this.route.snapshot.paramMap.get('id'));
  }

  deleteMovie() {
    this.movieService.deleteMovie(this.movieId).subscribe(() => {
      this.router.navigate(['/view']);
    });
  }

  cancel() {
    this.router.navigate(['/view']);
  }
}
