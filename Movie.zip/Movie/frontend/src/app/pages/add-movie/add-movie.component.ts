import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../model/movie.model';

@Component({
  selector: 'app-add-movie',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent {
  movie: Movie = {
    title: '',
    director: '',
    genre: '',
    releaseYear: new Date().getFullYear(),
    rating: 5
  };

  constructor(private movieService: MovieService) {}

  addMovie(form: NgForm) {
    if (!this.movie.title || !this.movie.director || !this.movie.genre) {
      alert('Please fill all the required fields!');
      return;
    }

    if (this.movie.rating < 1 || this.movie.rating > 10) {
      alert('Rating must be between 1 and 10.');
      return;
    }

    this.movieService.create(this.movie).subscribe({
      next: () => {
        alert('Movie added successfully!');
        form.resetForm();
      },
      error: () => {
        alert('Failed to add movie.');
      }
    });
  }
}
