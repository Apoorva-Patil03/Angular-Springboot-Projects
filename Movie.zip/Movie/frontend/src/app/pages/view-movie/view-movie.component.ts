import { Component, OnInit } from '@angular/core';
import { MovieService } from '../../services/movie.service';
import { Movie } from '../../model/movie.model';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-movies',
  standalone: true,
  imports: [CommonModule, CurrencyPipe],
  templateUrl: './view-movie.component.html',
  styleUrls: ['./view-movie.component.css']
})
export class ViewMovieComponent implements OnInit {
  movies: Movie[] = [];

  constructor(private movieService: MovieService, private router: Router) {}

  ngOnInit(): void {
    this.movieService.getAll().subscribe({
      next: (data) => this.movies = data,
      error: (err) => console.error('Error fetching movies', err)
    });
  }

  onUpdate(movieId: string): void {
    this.router.navigate(['/update-movie', movieId]);
  }

  onDelete(movieId: string): void {
    if (confirm('Are you sure you want to delete this movie?')) {
      this.movieService.delete(movieId).subscribe({
        next: () => {
          this.movies = this.movies.filter(m => m.movieId !== movieId);
        },
        error: (err) => console.error('Error deleting movie', err)
      });
    }
  }
}
