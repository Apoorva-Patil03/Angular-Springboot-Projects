// src/app/pages/update-movie/update-movie.component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService, Movie } from '../../services/movie.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-movie',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './update-movie.component.html',
  styleUrls: ['./update-movie.component.css']
})
export class UpdateMovieComponent implements OnInit {
  movieId!: number;
  movie: Movie = { title: '', director: '', genre: '', releaseYear: new Date().getFullYear() };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private movieService: MovieService
  ) {}

  ngOnInit(): void {
    this.movieId = Number(this.route.snapshot.paramMap.get('id'));
    this.movieService.getMovieById(this.movieId).subscribe(data => {
      this.movie = data;
    });
  }

  updateMovie() {
    this.movieService.updateMovie(this.movieId, this.movie).subscribe(() => {
      this.router.navigate(['/view']);
    });
  }
}
