import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { AddMovieComponent } from './pages/add-movie/add-movie.component';
import { ViewMovieComponent } from './pages/view-movie/view-movie.component';
import { UpdateMovieComponent } from './pages/update-movie/update-movie.component';
import { DeleteMovieComponent } from './pages/delete-movie/delete-movie.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'add-movie', component: AddMovieComponent },
  { path: 'view-movies', component: ViewMovieComponent },
  { path: 'update-movie/:id', component: UpdateMovieComponent },
  { path: 'delete-movie/:id', component: DeleteMovieComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
